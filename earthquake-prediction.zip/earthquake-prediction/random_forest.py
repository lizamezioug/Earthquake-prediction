import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.model_selection import train_test_split, cross_val_score
import time

# 📥 Charger les données
X_train = pd.read_csv("X_train.csv")
y_train = pd.read_csv("y_train.csv").squeeze()
X_test = pd.read_csv("X_test.csv")
y_test = pd.read_csv("y_test.csv").squeeze()

# 🧹 Nettoyage : Supprimer les lignes contenant des NaN
X_train = X_train.dropna()
y_train = y_train.loc[X_train.index]
X_test = X_test.dropna()
y_test = y_test.loc[X_test.index]

# 🔍 Vérification des valeurs manquantes
print(f"🔎 Valeurs manquantes X_train : {X_train.isna().sum().sum()} | y_train : {y_train.isna().sum()}")
print(f"🔎 Valeurs manquantes X_test  : {X_test.isna().sum().sum()} | y_test  : {y_test.isna().sum()}")

# Mesurer le temps d'exécution
start_time = time.time()
# 🌲 Création du modèle RandomForestRegressor
model = RandomForestRegressor(n_estimators=100, max_depth=10, min_samples_split=5, random_state=42)

# 🏋️ Entraînement
model.fit(X_train, y_train)

# 🔮 Prédictions
y_pred = model.predict(X_test)

# 📊 Évaluation
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"✅ Modèle Random Forest entraîné")
print(f"📉 MSE : {mse:.4f}")
print(f"📊 RMSE : {rmse:.4f}")
print(f"📈 MAE : {mae:.4f}")
print(f"🔍 R² score : {r2:.4f}")

# 📉 Visualisation : Résidus
residuals = y_test - y_pred
plt.figure(figsize=(10,5))
plt.scatter(y_pred, residuals, alpha=0.3)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel("Prédictions")
plt.ylabel("Résidus")
plt.title("Graphique des résidus (RandomForestRegressor)")
plt.savefig("residus_random_forest.png")
plt.show()

# 📈 Visualisation : Réel vs Prédit
plt.figure(figsize=(10,5))
plt.plot(y_test.values, label="Réel", alpha=0.7)
plt.plot(y_pred, label="Prédit (RandomForest)", alpha=0.7)
plt.legend()
plt.title("Comparaison Réel vs Prédit (RandomForestRegressor)")
plt.savefig("comparaison_random_forest.png")
plt.show()

# 📊 Validation croisée (5 folds) sur les données d'entraînement
scores_rf = cross_val_score(model, X_train, y_train, cv=10, scoring='neg_mean_squared_error')

# Affichage des résultats de la validation croisée
print(f"Scores pour Random Forest (Validation Croisée) : {scores_rf}")
print(f"Score moyen (MSE) : {-scores_rf.mean():.4f}")

end_time = time.time()
execution_time = end_time - start_time

print(f"⏰ Temps d'exécution de l'entraînement : {execution_time:.4f} secondes")