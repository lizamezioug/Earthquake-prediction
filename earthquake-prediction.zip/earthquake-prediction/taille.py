import pandas as pd

# Liste des datasets et leurs noms
datasets = {
    "Dataset origine": "Eartquakes-1990-2023.csv",
    "Dataset Nettoyé": "dataset_cleaned.csv",
    "Dataset Encodé": "encoded_dataset.csv",
    "X_train": "X_train.csv",
    "X_test": "X_test.csv",
    "y_train": "y_train.csv",
    "y_test": "y_test.csv"
}

# Afficher la taille de chaque dataset
for name, file in datasets.items():
    try:
        data = pd.read_csv(file)
        print(f"{name}: {data.shape[0]} lignes, {data.shape[1]} colonnes")
    except FileNotFoundError:
        print(f"{file} n'existe pas dans le répertoire courant.")
