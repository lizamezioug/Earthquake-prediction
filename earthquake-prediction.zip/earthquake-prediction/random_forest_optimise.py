import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.feature_selection import SelectKBest, f_regression
import time

# 📥 Charger les données
X_train = pd.read_csv("X_train.csv")
y_train = pd.read_csv("y_train.csv").squeeze()
X_test = pd.read_csv("X_test.csv")
y_test = pd.read_csv("y_test.csv").squeeze()

# 🧹 Nettoyage : Supprimer les lignes contenant des NaN
X_train = X_train.dropna()
y_train = y_train.loc[X_train.index]
X_test = X_test.dropna()
y_test = y_test.loc[X_test.index]

# Sélection des meilleures fonctionnalités
start_time = time.time()
select_k = SelectKBest(f_regression, k=7)
X_train_best = select_k.fit_transform(X_train, y_train)
X_test_best = select_k.transform(X_test)
selected_features = X_train.columns[select_k.get_support()].tolist()
print(f"Features sélectionnées : {selected_features}")

# Hyperparameter Tuning avec RandomizedSearchCV
param_grid = {
    'n_estimators': [50, 100, 150, 200],
    'max_depth': [5, 10, 15, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', None]
}

model = RandomForestRegressor(random_state=42)
random_search = RandomizedSearchCV(model, param_grid, n_iter=50, cv=5, scoring='neg_mean_squared_error', random_state=42)
random_search.fit(X_train_best, y_train)

best_params = random_search.best_params_
print(f"✅ Meilleurs paramètres : {best_params}")

# Modèle optimisé
optimized_model = RandomForestRegressor(**best_params, random_state=42)
optimized_model.fit(X_train_best, y_train)

# Prédictions
y_pred = optimized_model.predict(X_test_best)

# Évaluation
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"📉 MSE : {mse:.4f}")
print(f"📊 RMSE : {rmse:.4f}")
print(f"📈 MAE : {mae:.4f}")
print(f"🔍 R² score : {r2:.4f}")

# Visualisation : Résidus
residuals = y_test - y_pred
plt.figure(figsize=(10, 5))
plt.scatter(y_pred, residuals, alpha=0.3)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel("Prédictions")
plt.ylabel("Résidus")
plt.title("Graphique des résidus (Random Forest Optimisé)")
plt.savefig("residus_random_forest_optimized.png")
plt.show()

# Visualisation : Réel vs Prédit
plt.figure(figsize=(10, 5))
plt.plot(y_test.values, label="Réel", alpha=0.7)
plt.plot(y_pred, label="Prédit (Random Forest Optimisé)", alpha=0.7)
plt.legend()
plt.title("Comparaison Réel vs Prédit (Random Forest Optimisé)")
plt.savefig("comparaison_random_forest_optimized.png")
plt.show()

end_time = time.time()
execution_time = end_time - start_time
print(f"⏰ Temps d'optimisation : {execution_time:.4f} secondes")
