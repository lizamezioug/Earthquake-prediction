import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import SGDRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.model_selection import train_test_split, cross_val_score, RandomizedSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.feature_selection import SelectKBest, f_regression
from scipy.stats import loguniform

# Charger les données
X_train = pd.read_csv("X_train.csv")
y_train = pd.read_csv("y_train.csv").squeeze()
X_test = pd.read_csv("X_test.csv")
y_test = pd.read_csv("y_test.csv").squeeze()

# Nettoyage : Supprimer les lignes contenant des NaN
X_train = X_train.dropna()
y_train = y_train.loc[X_train.index]
X_test = X_test.dropna()
y_test = y_test.loc[X_test.index]

# Vérification des valeurs manquantes
print(f"🔎 Valeurs manquantes X_train : {X_train.isna().sum().sum()} | y_train : {y_train.isna().sum()}")
print(f"🔎 Valeurs manquantes X_test  : {X_test.isna().sum().sum()} | y_test  : {y_test.isna().sum()}")

# Fonction pour sélectionner les meilleures caractéristiques
def select_best_features(X, y, k=10):
    selector = SelectKBest(f_regression, k=k)
    X_new = selector.fit_transform(X, y)
    selected_features = X.columns[selector.get_support()]
    return X_new, selected_features

# Sélectionner les meilleures caractéristiques
X_train_best, best_features = select_best_features(X_train, y_train, k=10)
X_test_best = X_test[best_features]

print(f"✅ Meilleures caractéristiques sélectionnées : {best_features}")

# Création du pipeline polynômial (degré 2) + SGDRegressor
model = make_pipeline(
    PolynomialFeatures(degree=2, include_bias=False),
    SGDRegressor(max_iter=5000, tol=1e-3, random_state=42, early_stopping=True)
)

# Optimisation des hyperparamètres avec RandomizedSearchCV
param_dist = {
    'sgdregressor__alpha': loguniform(1e-5, 1e-1),
    'sgdregressor__penalty': ['l2', 'l1', 'elasticnet'],
    'sgdregressor__learning_rate': ['constant', 'optimal', 'invscaling'],
    'sgdregressor__eta0': [0.001, 0.01, 0.1],
    'sgdregressor__l1_ratio': [0, 0.15, 0.3, 0.5, 0.7, 0.85, 1]
}

random_search = RandomizedSearchCV(
    model,
    param_distributions=param_dist,
    n_iter=50,  # Nombre d'itérations de recherche
    cv=5,
    scoring='neg_mean_squared_error',
    random_state=42,
    n_jobs=-1,  # Utiliser tous les cœurs disponibles
    verbose=1
)

print("🔍 Début de la recherche aléatoire des hyperparamètres...")
random_search.fit(X_train_best, y_train)

# Afficher les meilleurs paramètres
print(f"\n✅ Meilleurs hyperparamètres : {random_search.best_params_}")

# Utiliser le meilleur modèle trouvé
best_model = random_search.best_estimator_

# Prédictions
y_pred = best_model.predict(X_test_best)

# Évaluation
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\n✅ Modèle optimisé (polynomial et hyperparamètres ajustés) entraîné")
print(f"📉 MSE : {mse:.4f}")
print(f"📊 RMSE : {rmse:.4f}")
print(f"📈 MAE : {mae:.4f}")
print(f"🔍 R² score : {r2:.4f}")

# 📊 Visualisation : Résidus
residuals = y_test - y_pred
plt.figure(figsize=(10,5))
plt.scatter(y_pred, residuals, alpha=0.3)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel("Prédictions")
plt.ylabel("Résidus")
plt.title("Graphique des résidus (Polynomial)")
plt.savefig("residus_polynomial_optimise.png")
plt.show()

# 📊 Visualisation : Réel vs Prédit
plt.figure(figsize=(10,5))
plt.plot(y_test.values, label="Réel", alpha=0.7)
plt.plot(y_pred, label="Prédit (Polynomial optimisé)", alpha=0.7)
plt.legend()
plt.title("Comparaison Réel vs Prédit (Polynomial optimisé)")
plt.savefig("comparaison_polynomial_optimise.png")
plt.show()