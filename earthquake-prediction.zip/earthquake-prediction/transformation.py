import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Charger le dataset nettoyé
df = pd.read_csv("dataset_cleaned.csv")
print(f"✅ Dataset chargé : {df.shape[0]} lignes et {df.shape[1]} colonnes")

# Encodage fréquentiel des colonnes catégorielles
cat_cols = ['place', 'status', 'data_type', 'state']
for col in cat_cols:
    freq = df[col].value_counts(normalize=True)
    df[col] = df[col].map(freq)

print("✅ Encodage fréquentiel terminé.")

# Transformation de la colonne date en datetime
df['date'] = pd.to_datetime(df['date'], errors='coerce')

# Transformation de la date en colonnes utiles
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
df['day'] = df['date'].dt.day
df['hour'] = df['date'].dt.hour
df = df.drop(columns=['date'])
print("✅ Transformation de la colonne date terminée.")

# Normalisation MinMax des colonnes numériques
colonnes_numeriques = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
scaler = MinMaxScaler()
df[colonnes_numeriques] = scaler.fit_transform(df[colonnes_numeriques])

print("✅ Normalisation MinMax des colonnes numériques terminée.")

# Sauvegarde du dataset encodé et normalisé
df.to_csv("encoded_dataset.csv", index=False)
print("💾 Dataset encodé + normalisé sauvegardé sous 'encoded_dataset.csv'")
